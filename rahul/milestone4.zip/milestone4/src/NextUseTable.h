#include "config.h"
#include "genTAC.cpp"

// The definition of the global next use table.

vector < pair < TAC*, map < string , pair < string, int > > > > nextUseTable;