#!/bin/bash
bin/asgn4 $1 
