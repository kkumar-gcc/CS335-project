public class test_8 {
    public static void main(String[] args) {
        /* This variable is *** added to check the ultimate level of errorCheck */
        double $Beaware = 0x0___00___0.1___1___1p0____0d;
        double $$NOOO = .0____0e-0_____0;
        long _$_$YEs = 0___7____3___2___1L;
        String p="hello world";
        /*** / ****/

        // Declare variables
        int[] arr = { 1, 2, 3 };

        String str = "Hello, world!";
        double d = 3.14159;
        boolean b = true;

        int i;
        for (i = 0; i < arr.length; i++) {
            while (i < 5) {
                if(i>3){
                    break;
                }
                i++;
            }
        }

    
        // Use a while loop
        
        if (b && ( arr[0] < 4 || i>2 )) {
            boolean ans = true;
        } else {
            boolean ans = true;
        }
    }

    public static int sumArray(int[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum;
    }

    // //Represent a node of binary tree  
    public static class Node{  
        int data;  
        Node left;  
        Node right;  
    }  

    public static void main2(String[] args) {  
        int d=6;
        //Add nodes to the binary tree  
          /*
          *
          /*
          *
          / You gotta ignore this comment dude!!!@#$%^%$^$%^$%
          *
          /*
          *
          */
           
      }
}
