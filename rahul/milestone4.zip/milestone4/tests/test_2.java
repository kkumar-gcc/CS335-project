public class test_2 {
    // Program with variables, operators and method declaration:
    public static int main(String[] args) {
        int num1 = 5;
        int num2 = 10;
        int sum = num1 + num2;
        return sum;
    }
}
