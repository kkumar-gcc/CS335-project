public class test_7 {
    int x = 5;
    /* Inner Class  */
    class Inner {
        public void printX() {
            int x;
        }
    }

    public static void main(String[] args) {
        int d=6;
    }
}
