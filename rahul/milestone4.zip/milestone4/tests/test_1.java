public class test_1 {
    // Basic program with Method Invocation:
    public static void pp(int C) {
        int x = C;
    }
    public static void Main(int a) {
        // int b = 2+-3;
        pp(a);
    }

}
