public class test_3 {
    // Program with conditional statements:
    public static void main(String[] args) {
        int j=0;
        int num = 10;
        if (num > 0) {
            int t;
            t = 2;
        } 
    }
}
