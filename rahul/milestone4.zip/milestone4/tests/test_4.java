public class test_4 {
    // Program with loops:
    public static void main(String[] args) {
        int i=1;
        for (; i <= 3; ) {
            i++;
        }
        for (i = 1; i <= 3; ) {
            i++;
        }
        for (; i <= 3; i++ ) {
            i++;
        }
        for (i = 1; i <= 3;i++ ) {
            i++;
        }
    }
}